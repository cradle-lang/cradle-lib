﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace pktmon_service
{
    public partial class PktmonService : ServiceBase
    {
        private readonly string _etlFile;
        private readonly string _pcapFile;
        private Process _pktmonProcess;

        public PktmonService()
        {
            InitializeComponent();
            
            this._etlFile = "C:\\Users\\vagrant\\capture.etl";
            this._pcapFile = "C:\\Users\\vagrant\\capture.pcap";
        }

        protected override void OnStart(string[] args)
        {
            Console.WriteLine("Starting PKTMON service");

            Process.Start(new ProcessStartInfo
            {
                FileName = "pktmon",
                Arguments = "filter add -d IPv4 -t TCP -i 192.168.0.0/16",
                UseShellExecute = true,
                CreateNoWindow = true
            }).WaitForExit();

            //Process.Start(new ProcessStartInfo
            //{
            //    FileName = "pktmon",
            //    Arguments = "filter add -t UDP -i 192.168.0.0/16",
            //    UseShellExecute = true,
            //    CreateNoWindow = true
            //}).WaitForExit();

            var psi = new ProcessStartInfo
            {
                FileName = "pktmon",
                Arguments = $"start --capture --pkt-size 0 --file-name \"{_etlFile}\"",
                UseShellExecute = true,
                CreateNoWindow = true,
            };

            _pktmonProcess = Process.Start(psi);
        }

        protected override void OnStop()
        {
            Console.WriteLine("Stopping PKTMON service");

            Process.Start(new ProcessStartInfo
            {
                FileName = "pktmon",
                Arguments = "stop",
                UseShellExecute = true,
                CreateNoWindow = true
            }).WaitForExit();

            Process.Start(new ProcessStartInfo
            {
                FileName = "pktmon",
                Arguments = $"etl2pcap \"{_etlFile}\" --out \"{_pcapFile}\"",
                UseShellExecute = true,
                CreateNoWindow = true
            }).WaitForExit();

            Process.Start(new ProcessStartInfo
            {
                FileName = "pktmon",
                Arguments = "filter remove",
                UseShellExecute = true,
                CreateNoWindow = true
            }).WaitForExit();

            _pktmonProcess.Dispose();
            _pktmonProcess = null;
        }

        public void StartService()
        {
            this.OnStart(new string[0]);
        }

        public void StopService() {
            this.OnStop();
        }
    }
}
