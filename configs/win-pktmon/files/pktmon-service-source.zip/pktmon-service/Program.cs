﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace pktmon_service
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main()
        {
            if (!Environment.UserInteractive)
            {
                // We are not in debug mode, startup as service

                ServiceBase[] ServicesToRun;
                ServicesToRun = new ServiceBase[] { new PktmonService() };
                ServiceBase.Run(ServicesToRun);
            }
            else
            {
                // We are in debug mode, startup as application
                Console.WriteLine("Running in debug mode.");
                PktmonService service = new PktmonService();
                service.StartService();
                System.Threading.Thread.Sleep(5 * 1000);
                service.StopService();
            }
        }
    }
}
